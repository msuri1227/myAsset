import UIKit

class CustomLoaderVC: UIViewController {

    @IBOutlet var contentView: UIView!
    
    @IBOutlet var loaderBtn: UIButton!
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet var statusLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        contentView.layer.cornerRadius = 8.0
        contentView.backgroundColor = UIColor.red
        loaderBtn.rotate360Degrees()
    }
}

/*extension UIViewController {
    func LoaderStart(status: String = "") {
        let childVC = CustomLoaderVC()
        childVC.view.frame = self.view.bounds
        childVC.view.tag = 10000
        childVC.statusLbl.text = status
        addChildViewController(childVC)
        view.addSubview(childVC.view)
        childVC.didMove(toParentViewController: self)
    }
    
    func LoaderStop() {
        Log.window.viewWithTag(10000)?.removeFromSuperview()
    }
}

extension UIButton {
    func rotate360Degrees(duration: CFTimeInterval = 0.5, completionDelegate: AnyObject? = nil) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        // rotateAnimation.toValue = CGFloat(.pi * 2.0)
        rotateAnimation.toValue = 360 * CGFloat(Double.pi / 180)
        let innerAnimationDuration : CGFloat = 0.5
        rotateAnimation.duration = Double(innerAnimationDuration)
        //rotateAnimation.duration = duration
        rotateAnimation.repeatCount = .infinity
        if let delegate: AnyObject = completionDelegate {
            rotateAnimation.delegate = delegate as? CAAnimationDelegate
        }
        self.layer.add(rotateAnimation, forKey: "nil")
    }
}*/

