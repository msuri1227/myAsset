//
//  CustomView.swift
//  LoaderDemo
//
//  Created by Ruby's Mac on 27/06/19.
//  Copyright © Ruby's Mac. All rights reserved.
//

import UIKit

class UIViewExtensions: UIView {
    
    @IBOutlet var contentView: UIView!
    
    @IBOutlet var loaderBtn: UIButton!
    
    @IBOutlet var statusLbl: UILabel!
    
    init() {
        super.init(frame: CGRect.zero)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomLoaderView", owner: self, options: nil)
        contentView.layer.cornerRadius = 8.0
        loaderBtn.rotate360Degrees()
    }

}

/*extension UIImageView {
    
    func rotate360Degrees1(duration: CFTimeInterval = 1, completionDelegate: AnyObject? = nil) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        //rotateAnimation.toValue = CGFloat(.pi * 2.0)
        rotateAnimation.toValue = 360 * CGFloat(Double.pi / 180)
        // rotateAnimation.duration = duration
        rotateAnimation.repeatCount = .infinity
        
        if let delegate: AnyObject = completionDelegate {
            rotateAnimation.delegate = delegate as? CAAnimationDelegate
        }
        self.layer.add(rotateAnimation, forKey: nil)
    }
}*/

extension UIButton {
    func rotate360Degrees(duration: CFTimeInterval = 0.5, completionDelegate: AnyObject? = nil) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        // rotateAnimation.toValue = CGFloat(.pi * 2.0)
        rotateAnimation.toValue = 360 * CGFloat(Double.pi / 180)
        let innerAnimationDuration : CGFloat = 0.5
        rotateAnimation.duration = Double(innerAnimationDuration)
        //rotateAnimation.duration = duration
        rotateAnimation.repeatCount = .infinity
        if let delegate: AnyObject = completionDelegate {
            rotateAnimation.delegate = delegate as? CAAnimationDelegate
       }
        self.layer.add(rotateAnimation, forKey: "nil")
    }
}

